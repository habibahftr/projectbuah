import React, { Component } from 'react';

class Body extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( 
            <div>ini body</div>
         );
    }
}
 
export default Body;