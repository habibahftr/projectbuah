let defaultState={
    isLogin: false,
    username:""
}

const authReducer = (state=defaultState, action)=>{
    console.warn("state: ", state)
    console.warn("action: ", action)
    switch (action.type) {
        case "LOGIN":
            return{
                isLogin: true,
            }
    
        default:
            return state;
    }
}

export default authReducer