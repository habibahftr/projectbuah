import React, { Component } from 'react';
import Regis from "./page/regis";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {  }
  }
  render() { 
    return ( 
      <>
      <Regis></Regis>
      </>
     );
  }
}
 
export default App;