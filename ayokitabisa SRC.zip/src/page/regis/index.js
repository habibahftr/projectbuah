import React, { Component } from 'react';
import { Label, Input, Option } from "../../component/form";
import { connect } from "react-redux"

class Regis extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            username:"",
            password:"",
            phone:"",
            email:"",
            role:"",
         }
    }

    setValue= el=>{
        this.setState({
            [el.target.name]: el.target.value
        })
    }

    setRegister = el =>{
        let obj = this.state
        this.props.register(obj);
        el.preventDefault()
        this.clear()

    }

    

    clear = () => {
        this.setState({ 
            username:"",
            password:"",
            phone:"",
            email:"",
            role:"",})
    }

    render() { 
        return ( 
            <div className="container">
                <h1>C R E A T A C C O U N T</h1>
                <div>
                    <Label>Username </Label> <Input type="text" name="username" value={this.state.username} onChange={this.setValue} placeholder="your username.." />
                    <Label>Password </Label> <Input type="text" name="password" value={this.state.password} onChange={this.setValue} placeholder="your password.." />
                    <Label>Phone Number </Label> <Input type="text" name="phone" value={this.state.phone} onChange={this.setValue} placeholder="your phone number.." />
                    <Label>Email </Label> <Input type="text" name="email" value={this.state.email} onChange={this.setValue} placeholder="your email.." />
                    <Label>Role </Label>
                    {/* <select value={this.state.role} onChange={this.setValue} defaultValue="Select Role">
                        <Option defaultvalue>Select Role</Option>
                        <Option value="admin">Admin</Option>
                        <Option value="staff">Staff</Option>
                    </select><br/> */}
                    <button type="submit" value="submit" onClick={this.setRegister} >Sign Up</button>
                </div>

            </div>
         );
    }
}


const mapStateToProps = state => ({
    dataUser: state.UReducer.users
    
  })
  
const mapDispatchToProps = dispatch => {
    return {
        register: (data)=> dispatch({type:"REGISTER", payload: data}),
    }
  }
 
export default connect(mapStateToProps, mapDispatchToProps) (Regis);