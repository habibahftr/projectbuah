import React, { Component } from 'react';
import { Label, Input } from "../../component/form";

class Login extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            username:"",
            password:"",
         }
    }

    setValue= el=>{
        this.setState({
            [el.target.name]: el.target.value
        })
    }
    render() { 
        return ( 
            <>
                <Label>Username </Label>
                <Input type="text" name="username" onChange={this.setValue} placeholder="username.."></Input>
                <Label>Password </Label>
                <Input type="password" name="password" onChange={this.setValue}></Input>
            </>
         );
    }
}
 
export default Login;