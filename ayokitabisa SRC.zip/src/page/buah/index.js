import React, { Component } from 'react';

class Buah extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( 
            <div>ini buah</div>
         );
    }
}
 
export default Buah;