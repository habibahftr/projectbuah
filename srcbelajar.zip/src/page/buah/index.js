import React, { Component } from 'react';

class Buah extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( 
            <>ini buah</>
         );
    }
}
 
export default Buah;